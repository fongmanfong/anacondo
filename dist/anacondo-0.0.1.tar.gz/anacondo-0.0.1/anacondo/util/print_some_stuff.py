def print_test():
	print ('ok')